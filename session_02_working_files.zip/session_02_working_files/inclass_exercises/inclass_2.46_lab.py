# 2.46:  Loop through and print 'column' values in a list of
# dicts.

# Using a loop, print the years one after the other.

import runreport

lol = [
    { 'name': 'Indiana',
      'year': '1816',
      'pop':  6.7
    },
    { 'name': 'Georgia',
      'year': '1788',
      'pop':  10.6
    },
    { 'name': 'Alabama',
      'year': '1819',
      'pop':  4.9
    }
]



# Expected Output:

# 1816
# 1788
# 1819

