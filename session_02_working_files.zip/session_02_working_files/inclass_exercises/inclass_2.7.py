# 2.7:  Create a new table called 'test', with columns 'name'
# (a TEXT column), 'years' (INT) and 'revenue' (a FLOAT
# column).  Use the .schema to verify the table's existence
# and have the query echoed back to you.

# sqlite> CREATE TABLE test (name TEXT, years INT, revenue FLOAT);
# sqlite> .schema test
# CREATE TABLE test (name TEXT, years INT, revenue FLOAT);

