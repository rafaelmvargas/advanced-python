# 2.18:  SELECT query from database prompt.

# Select all rows and columns from the planets table.

# Expected Output:

# planet      mass        distance
# ----------  ----------  ----------
# Mercury     0.33        58
# Venus       4.87        108
# Earth       5.98        150

