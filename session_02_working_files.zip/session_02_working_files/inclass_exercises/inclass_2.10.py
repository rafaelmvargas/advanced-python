# 2.10:  Insert a row into the test table.  Run the query a
# few times by pressing the up arrow and hitting [Enter]

# sqlite> INSERT INTO test VALUES ('Joe', 23, 23.95);

# Note that TEXT column values must have quotes around them
# and INT and FLOAT column values must not.

