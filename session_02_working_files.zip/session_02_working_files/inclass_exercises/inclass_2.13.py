# 2.13:  Drop table entirely.

# sqlite> DROP TABLE test;

