# 2.4:  Set display columns.  This configures SQLite to show
# SELECT output in columns with headers.

# sqlite> .header on
# sqlite> .mode column

