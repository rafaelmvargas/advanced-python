# 2.17:  INSERT query from database prompt.

# Insert each of the following rows of values into the planets
# table by executing 3 separate INSERT query statements:

# Mercury   .33    58
# Venus    4.87   108
# Earth    5.98   150

# The sqlite prompt should return without error after each
# INSERT query.

