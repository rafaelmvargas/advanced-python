# 2.5:  Show the schema for a table.  Use the .schema command
# to see the CREATE TABLE for the revenue table, which shows
# its structure.

# show schema for a table:

# sqlite> .schema revenue

