# 2.9:  Recreate the table test by using the up arrow to
# retrieve the original CREATE TABLE statement.  (Make sure
# not to retype the CREATE TABLE statement - you don't need
# to!)

#  Use the up arrow (twice) on the SQLite3 client, no need to
# retype:

# sqlite> CREATE TABLE test (name TEXT, years INT, revenue FLOAT);

