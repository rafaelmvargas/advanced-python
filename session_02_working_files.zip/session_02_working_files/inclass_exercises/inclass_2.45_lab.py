# 2.45:  Loop through and print 'column' values in a list of
# lists.

# Using a loop, print the state names one after the other.

import runreport

lol = [
    [ 1816,   6.7,  'Indiana' ],
    [ 1788,  10.6,  'Georgia' ],
    [ 1819,  4.9,   'Alabama' ]
]

# Expected Output:

# Indiana
# Georgia
# Alabama

