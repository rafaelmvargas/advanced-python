# 2.15:  Issue a .tables command to verify that you have
# opened the existing session_2.db file:

# .tables

# Expected Output:

# ad_buys         companyrev      student_status  user
# ad_companies    revenue         students        user_classes

# (please note that your table listing may be different than
# shown above, but should at least show several tables rather
# than no tables)
# 
# If there are no tables listed, use .quit to leave sqlite3,
# use ls or dir to see that you have created a new, empty .db
# file (you can check the size in your Windows Explorer or Mac
# Finder view of the file), and then delete this file.  Then
# return to the start of these exercises and follow directions
# to find the existing session_2.db file.

