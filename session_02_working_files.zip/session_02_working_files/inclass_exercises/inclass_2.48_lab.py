# 2.48:  Loop through and print 'column' values in a dict of
# dicts.

# Using a loop, print the populations, one after the other.

import runreport

dod = {
    'Indiana':  {
                   'year': '1816',
                   'pop':  6.7
                },
    'Georgia':  {
                   'year': '1788',
                   'pop':  10.6
                },
    'Alabama':  {
                   'year': '1819',
                   'pop':  4.9
                }
}

# Expected Output:

# 6.7
# 10.6
# 4.9

