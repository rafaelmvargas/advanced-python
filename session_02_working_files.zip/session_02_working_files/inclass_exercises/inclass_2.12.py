# 2.12:  Delete all rows from the table.

# sqlite> DELETE FROM test;

