# 2.19:  SELECT query for specific columns with WHERE clause
# from database prompt.

# Select the planet and and distance columns for all planets
# further than 100 (km) from the sun.

# Expected Output:

# planet      distance
# ----------  ----------
# Venus       108
# Earth       150

