# 2.1:  Open a Anaconda Prompt (Windows) or a Terminal window
# (Mac).  (To reach the Anaconda prompt, do a search for
# Anaconda and click Anaconad Prompt.)

#   * (Unix only) Use pwd to see the "present working
# directory"
#   * Use ls (Mac) or dir (Windows) to see a listing of the
# files and directories in this directory
#   * Use cd to move into a directory you see listed in the
# present working directory (for example cd Downloads)
#   * Use cd .. to move into the "parent" directory of the one
# you are in (this will take you back to the parent of
# Downlaods
#   * Use cd /Users/[yourhomedir]/Desktop to move into the
# Desktop directory
#   * Use cd ../Downloads to move from the Desktop directory
# to the Downloads directory
#   * Use cd (Mac) or cd %HOMEPATH% (Windows) to move back
# into the home directory
# 

