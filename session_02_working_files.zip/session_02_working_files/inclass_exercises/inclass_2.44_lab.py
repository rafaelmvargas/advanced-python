# 2.44:  Access item in a list of lists.

import runreport

lol = [
    [ 1816,   6.7,  'Indiana' ],
    [ 1788,  10.6,  'Georgia' ],
    [ 1819,   4.9,  'Alabama' ]
]


# Access the value 10.6 and print it.

# Expected Output:

# 10.6

