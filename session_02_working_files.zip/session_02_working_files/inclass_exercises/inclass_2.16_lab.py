# 2.16:  CREATE TABLE from database prompt.

# Create a table called planets with the following columns:

# planet (a TEXT field)
# mass (a FLOAT field)
# distance (an INT field)

# When done, issue a .schema query to see the query and
# structure of the table reflected back to you.

