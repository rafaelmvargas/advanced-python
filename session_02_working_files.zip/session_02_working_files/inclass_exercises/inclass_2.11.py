# 2.11:  Run a select query to display the rows you inserted.

# sqlite> SELECT * FROM test;

