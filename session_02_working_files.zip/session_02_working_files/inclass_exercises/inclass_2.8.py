# 2.8:  Drop the table you just created.

# sqlite> DROP TABLE test;

